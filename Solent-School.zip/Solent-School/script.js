
const translations = {
    english: {
        welcome_to: "Welcome to",
        school_name: "Solent School",
        info_main_para: "Situated on the banks of the Itchen River, Solent School has been providing academic excellence since 1965. We are confident that our staff, facilities and guidance can provide all our students with the necessary skills to excel in their academic journey."
    },
    arabic: {
        welcome_to: "مرحبًا بكم في",
        school_name: "مدرسة سولنت",
        info_main_para: "تقع مدرسة سولنت على ضفاف نهر إيتشن، وقد قدمت التميز الأكاديمي منذ عام 1965. نحن واثقون من أن موظفينا ومرافقنا وإرشاداتنا يمكن أن تزود جميع طلابنا بالمهارات اللازمة للتميز في رحلتهم الأكاديمية."
    },
    chinese: {
        welcome_to: "欢迎来到",
        school_name: "索伦特学校",
        info_main_para: "索伦特学校坐落在伊滕河畔，自1965年以来一直提供卓越的学术服务。我们相信我们的员工、设施和指导可以为所有学生提供必要的技能，使他们在学术旅程中脱颖而出。"
    },
    polish: {
        welcome_to: "Witamy w",
        school_name: "Szkole Solent",
        info_main_para: "Położona na brzegach rzeki Itchen, Szkoła Solent zapewnia doskonałość akademicką od 1965 roku. Jesteśmy pewni, że nasz personel, zaplecze i wskazówki mogą zapewnić wszystkim naszym uczniom niezbędne umiejętności do osiągnięcia sukcesu w ich akademickiej podróży."
    }
};

document.getElementById('language_select').addEventListener('change', function() {
    console.log('Language select change event fired');
    const selectedLanguage = this.value;
    console.log('Selected language:', selectedLanguage);
    const translation = translations[selectedLanguage];
    console.log('Translation:', translation);

    document.getElementById('welcome_to').innerText = translation.welcome_to;
    document.getElementById('school_name').innerText = translation.school_name;
    document.getElementById('info_main_para').innerText = translation.info_main_para;
});


